﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NorthwindRT.DAL
{
    public sealed class FileWatcher
    {
        System.IO.FileSystemWatcher _watcher;

        public FileWatcher()
        {
            _watcher = new System.IO.FileSystemWatcher(@"C:\nwind_RT_demo");
            _watcher.Created += _watcher_Created;
            _watcher.EnableRaisingEvents = true;
        }

        void _watcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {
            if (FileCreated != null)
                FileCreated(this, e.Name);
        }

        public event EventHandler<string> FileCreated;

    }
}
