﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Northwind.WinForms
{
    public partial class OrderItemDetail : Form
    {
        public int Quanity { get; set; }

        public OrderItemDetail()
        {
            InitializeComponent();
            Quanity = 1;
            nudQuanity.Value = 1;
        }

        public void SetProductName( string name)
        {
            tbName.Text = name;
        }

        public void SetProductDesc( string desc)
        {
            tbDescription.Text = desc;
        }

        public void SetPrice(string price)
        {
            tbPrice.Text = price;
        }

        public void SetQuanity(int quanity)
        {
            nudQuanity.Value = quanity;
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Quanity = (int) nudQuanity.Value;
            Close();
        }
    }
}
