﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind.WinForms
{
    public sealed class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public Image  Image { get; set; }
    }

    public sealed class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string QuantityPerUnit { get; set; }
        public float UnitPrice { get; set; }
        public short UnitsInStock { get; set; }
        public short UnitsOnOrder { get; set; }
        public short ReorderLevel { get; set; }
        public bool Discontinued { get; set; }
        public int SupplierID { get; set; }
        public int CategoryID { get; set; }

        public Brush Color { get { return UnitsInStock > 0 ? System.Drawing.Brushes.Green : System.Drawing.Brushes.Red; } }
        public bool Available { get { return UnitsInStock > 0; } }
    }

    public sealed class ViewModel 
    {
        public static readonly ViewModel Instance = new ViewModel();

        public readonly ObservableCollection<Category> Categories = new ObservableCollection<Category>();
        private readonly ObservableCollection<Product> _products = new ObservableCollection<Product>();
        private readonly ObservableCollection<Product> _order = new ObservableCollection<Product>();
        public ObservableCollection<Product> Products { get { return _products; } }
        public ObservableCollection<Product> Order { get { return _order; } }

        private float _total;
        public float Total
        {
            get { return _total; }
            set
            {
                _total = value;
            }
        }

        public void LoadCategories()
        {
            Categories.Clear();

            // images are loaded from local assets
            var images = new[] { "beverages", "condiments", "confections", "dairy-products", "grains-cereals", "meat-poultry", "produce", "seafood" };

            var database = new Northwind.DAL.NorthwindDatabase();
            var categories = database.GetCategories();

            foreach (var c in categories)
            {
                //var uri = new Uri(string.Format("ms-appx:///Assets/{0}.bmp", images[count++]));
                Categories.Add(new Category { Id = c.ID, Name = c.Name, Description = c.Description, Image = null });
            }
        }

        public void LoadProductsForCategory(int categoryId)
        {
            Products.Clear();

            var database = new Northwind.DAL.NorthwindDatabase();
            var products = database.GetProductsByCategory(categoryId);

            foreach (var p in products)
            {
                Products.Add(new Product { Id = p.ID, Name = p.Name, UnitPrice = p.UnitPrice, QuantityPerUnit = p.QuantityPerUnit, UnitsInStock = p.UnitsInStock });
            }
        }

        public void UpdateTotal()
        {
            Total = _order.Sum(p => p.UnitPrice);
        }


        internal void CheckOut()
        {
            Order.Clear();
            UpdateTotal();
        }
    }
}
