﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace NorthwindRT.WinRtClient
{

    public sealed class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public BitmapImage Image { get; set; }
    }

    public sealed class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string QuantityPerUnit { get; set; }
        public float UnitPrice { get; set; }
        public short UnitsInStock { get; set; }
        public short UnitsOnOrder { get; set; }
        public short ReorderLevel { get; set; }
        public bool Discontinued { get; set; }
        public int SupplierID { get; set; }
        public int CategoryID { get; set; }

        public SolidColorBrush Color { get { return UnitsInStock > 0 ? new SolidColorBrush(Colors.Green) : new SolidColorBrush(Windows.UI.Color.FromArgb(0xff, 0xff, 0x8c, 0x00)); } }
        public bool Available { get { return UnitsInStock > 0; } }
    }

    public sealed class ViewModel : INotifyPropertyChanged
    {
        public static readonly ViewModel Instance = new ViewModel();

        public readonly ObservableCollection<Category> Categories = new ObservableCollection<Category>();
        private readonly ObservableCollection<Product> _products = new ObservableCollection<Product>();
        private readonly ObservableCollection<Product> _order = new ObservableCollection<Product>();
        public ObservableCollection<Product> Products { get { return _products; } }
        public ObservableCollection<Product> Order { get { return _order; } }

        private float _total;
        public float Total
        {
            get { return _total; }
            set
            {
                _total = value;
                NotifyPropertyChanged();
            }
        }

        public async Task LoadCategoriesAsync()
        {
            Categories.Clear();

            // images are loaded from local assets
            var images = new[] { "beverages", "condiments", "confections", "dairy-products", "grains-cereals", "meat-poultry", "produce", "seafood" };

            var northwind = new NorthwindRT.DAL.Database();
            var categories = await northwind.GetCategoriesAsync();

            var count = 0;
            foreach (var c in categories)
            {
                var uri = new Uri(string.Format("ms-appx:///Assets/{0}.png", images[count++]));
                Categories.Add(new Category { Id = c.ID, Name = c.Name, Description = c.Description, Image = new BitmapImage(uri) });
            }
        }

        public async Task LoadProductsForCategoryAsync(Category category)
        {
            Products.Clear();

            var northwind = new NorthwindRT.DAL.Database();
            var products = await northwind.GetProductsByCategoryAsync(category.Id);

            foreach (var p in products)
            {
                Products.Add(new Product { Id = p.ID, Name = p.Name, UnitPrice = p.UnitPrice, QuantityPerUnit = p.QuantityPerUnit, UnitsInStock = p.UnitsInStock });
            }
        }

        public void UpdateTotal()
        {
            Total = _order.Sum(p => p.UnitPrice);
        }

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        internal void CheckOut()
        {
            Order.Clear();
            UpdateTotal();
        }
    }
}
