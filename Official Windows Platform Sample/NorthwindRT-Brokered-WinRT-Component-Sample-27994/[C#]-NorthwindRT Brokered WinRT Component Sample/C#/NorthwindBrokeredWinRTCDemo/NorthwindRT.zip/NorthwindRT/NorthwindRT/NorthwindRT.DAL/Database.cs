﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;

namespace NorthwindRT.DAL
{
    public struct Category
    {
        public int ID;
        public string Name;
        public string Description;
    }

    public struct Product
    {
        public int ID;
        public string Name;
        public string QuantityPerUnit;
        public float UnitPrice;
        public short UnitsInStock;
        public short UnitsOnOrder;
        public short ReorderLevel;
        public bool Discontinued;
        public int SupplierID;
        public int CategoryID;
    }

    public sealed class Database
    {
        private IEnumerable<Category> GetCategories()
        {
            var oldDB = new Northwind.DAL.NorthwindDatabase();
            foreach (var cat in oldDB.GetCategories())
            {
                yield return new Category
                {
                    ID = cat.ID,
                    Description = cat.Description,
                    Name = cat.Name,
                };
            }
        }

        private IEnumerable<Product> GetProductsByCategory(int categoryID)
        {
            var oldDB = new Northwind.DAL.NorthwindDatabase();
            foreach (var prod in oldDB.GetProductsByCategory(categoryID))
            {
                yield return new Product
                {
                    ID = prod.ID,
                    CategoryID = prod.CategoryID,
                    Discontinued = prod.Discontinued,
                    Name = prod.Name,
                    QuantityPerUnit = prod.QuantityPerUnit,
                    ReorderLevel = prod.ReorderLevel,
                    SupplierID = prod.SupplierID,
                    UnitPrice = prod.UnitPrice,
                    UnitsInStock = prod.UnitsInStock,
                    UnitsOnOrder = prod.UnitsOnOrder,
                };
            }
        }

        public IAsyncOperation<IEnumerable<Category>> GetCategoriesAsync()
        {
            return Task.Run(() => GetCategories()).AsAsyncOperation();
        }

        public IAsyncOperation<IEnumerable<Product>> GetProductsByCategoryAsync(int categoryId)
        {
            return Task.Run(() => GetProductsByCategory(categoryId)).AsAsyncOperation();
        }
    }
}
