﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Northwind.WinForms
{
    public partial class QuickOrder : Form
    {
        ViewModel model = new ViewModel();
        double total = 0.0;

        public QuickOrder()
        {
            InitializeComponent();
            btnAddToOrder.Enabled = false;
            tbCost.Text = total.ToString();
            Start();
        }

        private async void Start()
        {
            await Task.Run(() => model.LoadCategories());

            foreach (Category c in model.Categories)
            {
                ListViewItem lvi = new ListViewItem(c.Name);
                lvi.Tag = c.Id;
                this.lvCategories.Items.Add(lvi);
            }
        }

        private async void lvCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvCategories.SelectedItems.Count == 1)
            {
                lvProducts.Items.Clear();
                btnAddToOrder.Enabled = false;
                ListViewItem lviCategory = lvCategories.SelectedItems[0];
                int CatID = Convert.ToInt32(lviCategory.Tag);
                await Task.Run(() => model.LoadProductsForCategory(CatID));
                foreach (Product p in model.Products)
                {
                    ListViewItem lvi = new ListViewItem(p.Name);
                    lvi.Tag = p.Id;
                    lvi.SubItems.Add(p.QuantityPerUnit);
                    lvi.SubItems.Add(p.UnitPrice.ToString());
                    lvi.SubItems.Add(p.UnitsInStock.ToString());
                    lvProducts.Items.Add(lvi);
                }
            }
        }

        private void btnSubmitOrder_Click(object sender, EventArgs e)
        {
            lvOrder.Items.Clear();
            total = 0.0;
            tbCost.Text = total.ToString();
        }

        private void lvProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ( lvProducts.SelectedItems.Count == 1)
            {
                btnAddToOrder.Enabled = true;
            }
            else
            {
                btnAddToOrder.Enabled = false;
            }
        }

        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            ListViewItem lviProduct = lvProducts.SelectedItems[0];
            OrderItemDetail details = new OrderItemDetail();
            details.SetProductName(lviProduct.Text);
            details.SetProductDesc(lviProduct.SubItems[1].Text);
            details.SetPrice(lviProduct.SubItems[2].Text);

            details.ShowDialog();

            ListViewItem OrderItem = new ListViewItem(details.Quanity.ToString());
            OrderItem.SubItems.Add(lviProduct.Text);
            OrderItem.SubItems.Add(lviProduct.SubItems[2].Text);
            double cost = Convert.ToDouble(lviProduct.SubItems[2].Text) * details.Quanity;
            OrderItem.SubItems.Add(cost.ToString());
            lvOrder.Items.Add(OrderItem);
            total += cost;
            tbCost.Text = total.ToString();
        }
    }
}
