﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace RestServiceHost
{
    public class CategoriesController : ApiController
    {
        public IEnumerable<string> Get()
        {
            using (var db = new NorthwindEntities())
            {
                var cats = db.Categories
                    .Select(c => c.CategoryName)
                    .ToList();

                return cats.Select(name => WebUtility.UrlEncode(name.Replace('/', '-')));
            }
        }
    }

    public class ProductsController : ApiController
    {
        public IEnumerable<Product> Get()
        {
            using (var db = new NorthwindEntities())
            {
                var p = db.Products
                    .Include("Category")
                    .Include("Supplier")
                    .ToList();

                return p;
            }
        }

        public IEnumerable<Product> Get(string id)
        {
            var category_name = WebUtility.UrlDecode(id.Replace('-', '/'));

            using (var db = new NorthwindEntities())
            {
                var products = db.Products
                    .Include("Category")
                    .Include("Supplier")
                    .Where(p => string.Compare(p.Category.CategoryName, category_name, true) == 0)
                    .ToList();

                return products;
            }
        }
    }
}
