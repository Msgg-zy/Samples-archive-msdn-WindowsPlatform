﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestServiceHost
{
    public class ProductJsonConverter : JsonConverter
    {
        public override bool CanRead
        {
            get { return false; }
        }

        public override bool CanConvert(Type objectType)
        {
            return typeof(Product).IsAssignableFrom(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }

        public override bool CanWrite
        {
            get { return true; }
        }

        //Discontinued = p.Discontinued,
        //QuantityPerUnit = p.QuantityPerUnit,
        //ReorderLevel = p.ReorderLevel,
        //UnitPrice = p.UnitPrice,
        //UnitsInStock = p.UnitsInStock,
        //UnitsOnOrder = p.UnitsOnOrder,

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            var p = value as Product;

            writer.WriteStartObject();
            writer.WritePropertyName("id");
            writer.WriteValue(p.ProductID);
            writer.WritePropertyName("name");
            writer.WriteValue(p.ProductName);
            writer.WritePropertyName("discontinued");
            writer.WriteValue(p.Discontinued);
            writer.WritePropertyName("quantityPerUnit");
            writer.WriteValue(p.QuantityPerUnit);
            writer.WritePropertyName("reorderLevel");
            writer.WriteValue(p.ReorderLevel);
            writer.WritePropertyName("unitPrice");
            writer.WriteValue(p.UnitPrice);
            writer.WritePropertyName("unitsInStock");
            writer.WriteValue(p.UnitsInStock);
            writer.WritePropertyName("unitsOnOrder");
            writer.WriteValue(p.UnitsOnOrder);

            writer.WritePropertyName("category");
            writer.WriteStartObject();
            writer.WritePropertyName("id");
            writer.WriteValue(p.Category.CategoryID);
            writer.WritePropertyName("name");
            writer.WriteValue(p.Category.CategoryName);
            writer.WriteEndObject();

            writer.WritePropertyName("supplier");
            writer.WriteStartObject();
            writer.WritePropertyName("id");
            writer.WriteValue(p.Supplier.SupplierID);
            writer.WritePropertyName("companyName");
            writer.WriteValue(p.Supplier.CompanyName);
            writer.WriteEndObject();

            writer.WriteEndObject();
        }
    }
}
