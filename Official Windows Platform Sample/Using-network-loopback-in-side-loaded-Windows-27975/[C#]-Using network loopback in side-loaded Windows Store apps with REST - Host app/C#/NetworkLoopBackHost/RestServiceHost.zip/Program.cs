﻿using Microsoft.AspNet.SignalR;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace RestServiceHost
{
    class Program
    {
        public class MyConnection : PersistentConnection
        {
            protected override Task OnReceived(IRequest request, string connectionId, string data)
            {
                // Broadcast data to all clients
                Console.WriteLine("{0} {1}", connectionId, data);
                string it = new string(data.Reverse().ToArray());

                return Connection.Send(connectionId, it);
            }
        }

        public class Startup
        {
            public void Configuration(IAppBuilder app)
            {
                var config = new HttpConfiguration();
                config.Routes.MapHttpRoute(
                    name: "DefaultApi",
                    routeTemplate: "api/{controller}/{id}",
                    defaults: new { id = RouteParameter.Optional }
                );
                //Add a custom JSON converter for Product to eliminate circuluar references 
                config.Formatters.JsonFormatter.SerializerSettings.Converters.Add(new ProductJsonConverter());

                app.UseWebApi(config);
                app.MapSignalR<MyConnection>("/myconnection");
            }
        }
        static void Main(string[] args)
        {
            string baseAddress = "http://localhost:9000/";

            using (Microsoft.Owin.Hosting.WebApp.Start<Startup>(baseAddress))
            {
                //HttpClient client = new HttpClient();

                //HttpResponseMessage response;
                
                //response = client.GetAsync(baseAddress + "api/categories").Result;
                //Console.WriteLine(response);
                //Console.WriteLine(response.Content.ReadAsStringAsync().Result);

                //response = client.GetAsync(baseAddress + "api/products").Result;
                //Console.WriteLine(response);
                //Console.WriteLine(response.Content.ReadAsStringAsync().Result);

                //response = client.GetAsync(baseAddress + "api/products/beverages").Result;
                //Console.WriteLine(response);
                //Console.WriteLine(response.Content.ReadAsStringAsync().Result);

                Console.WriteLine("REST service is ready at {0}", baseAddress);
                Console.WriteLine("Enter message to send, empty line to exit");

                var ctx = GlobalHost.ConnectionManager.GetConnectionContext<MyConnection>();
                var line = Console.ReadLine();
                while (!string.IsNullOrWhiteSpace(line))
                {
                    ctx.Connection.Broadcast(line);
                    line = Console.ReadLine();
                }
            }
        }
    }
}
