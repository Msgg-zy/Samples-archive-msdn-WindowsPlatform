﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Xml.Linq;

namespace RestServiceHost
{
    public class Book
    {
        public string Id { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public decimal Price { get; set; }
        public DateTime PublishDate { get; set; }
        public string Description { get; set; }

        static List<Book> _books = null;
        public static IEnumerable<Book> Books
        {
            get 
            {
                if (_books == null)
                {

                    _books = XDocument.Load("books.xml")
                        .Root
                        .Elements("book")
                        .Select(e => new Book
                        {
                            Id = e.Attribute("id").Value,
                            Author = e.Element("author").Value,
                            Title = e.Element("title").Value,
                            Genre = e.Element("genre").Value,
                            Description = e.Element("description").Value,
                            Price = Decimal.Parse(e.Element("price").Value),
                            PublishDate = DateTime.Parse(e.Element("publish_date").Value),
                        })
                        .ToList();
                }

                return _books;
            }
        }
    }

    public class GenresController : ApiController
    {
        // GET api/genres 
        public IEnumerable<string> Get()
        {
            return Book.Books.Select(b => WebUtility.UrlEncode(b.Genre)).Distinct();
        }
    }

    public class BooksController : ApiController
    {
        // GET api/books
        public IEnumerable<Book> Get()
        {
            return Book.Books;
        }


        // GET api/books/Fantasy
        public IEnumerable<Book> Get(string id)
        {
            var genre = WebUtility.UrlDecode(id);
            return Book.Books.Where(b => string.Compare(b.Genre, genre, true) == 0);
        }
    }
}
